# /bin/sh

for i in {1..8}; do
    ./ghema scp5$i.txt out5$i.txt 34;
done
./ghema scp59.txt out59.txt  35;
./ghema scp510.txt out510.txt 34;
#for file in ./sh/*;do
#    echo $file
#    qsub $file
#done

