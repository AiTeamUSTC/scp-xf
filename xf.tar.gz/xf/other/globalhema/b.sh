# /bin/sh
./ghema scp41.txt out41.txt 38;
./ghema scp42.txt out42.txt 37;
for i in {3..5}; do
    ./ghema scp4$i.txt out4$i.txt 38;
done
./ghema scp46.txt out46.txt 37;
./ghema scp47.txt out47.txt 38;
./ghema scp48.txt out48.txt 37;
for i in {9..10}; do
    ./ghema scp4$i.txt out4$i.txt 38;
done
#for file in ./sh/*;do
#    echo $file
#    qsub $file
#done
