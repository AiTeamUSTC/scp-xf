# /bin/sh
./ghema scp61.txt out61.txt 21;
./ghema scp62.txt out62.txt 20;
./ghema scp63.txt out63.txt 21;
./ghema scp64.txt out64.txt 20;
./ghema scp65.txt out65.txt 21;
#for file in ./sh/*;do
#    echo $file
#    qsub $file
#done

