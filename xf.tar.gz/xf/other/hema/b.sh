# /bin/sh

for i in {1..10}; do
    ./hema scp4$i.txt out4$i.txt 41;
done
#for file in ./sh/*;do:  
#    echo $file
#    qsub $file
#done
