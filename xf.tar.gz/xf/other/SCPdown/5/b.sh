# /bin/sh
./5 scp51.txt out51.txt 51 34;
./5 scp52.txt out52.txt 51 34;
./5 scp53.txt out53.txt 51 34;
./5 scp55.txt out55.txt 51 34;
./5 scp55.txt out55.txt 51 34;
./5 scp56.txt out56.txt 51 34;
./5 scp57.txt out57.txt 51 34;
./5 scp58.txt out58.txt 51 34;
./5 scp59.txt out59.txt 51 35;
./5 scp510.txt out510.txt 51 34;
#for i in {3..10}; do
#    ./5 scp5$i.txt out5$i.txt 51 38;
#done
#for file in ./sh/*;do
#    echo $file
#    qsub $file
#done
