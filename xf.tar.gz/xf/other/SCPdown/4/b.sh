# /bin/sh
./4 scp41.txt out41.txt 41 38;
./4 scp42.txt out42.txt 41 37;
./4 scp43.txt out43.txt 41 38;
./4 scp44.txt out44.txt 41 38;
./4 scp45.txt out45.txt 41 38;
./4 scp46.txt out46.txt 41 37;
./4 scp47.txt out47.txt 41 38;
./4 scp48.txt out48.txt 41 37;
./4 scp49.txt out49.txt 41 38;
./4 scp410.txt out410.txt 41 38;
#for i in {3..10}; do
#    ./4 scp4$i.txt out4$i.txt 41 38;
#done
#for file in ./sh/*;do
#    echo $file
#    qsub $file
#done
