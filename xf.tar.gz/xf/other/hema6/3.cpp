#include<stdio.h> 
#include<stdlib.h>
#include<fstream>
#include<memory.h>
#include<vector>
#include<algorithm>
#include<iostream>
#include<limits.h>
#include<float.h>
#include<time.h> 
#include "func.h"
using namespace std;
/*********������*******************/
int main(int argc, char *argv[])
{       
        srand((unsigned)time(NULL));//��������� 
	char*filename = argv[1];
	//��Ⱥ��ģ 
	build_instance(filename);
	//srand(40);
        ofstream output;
        char *outname = argv[2];
	output.open(outname);
        int tc = atoi(argv[3]);
        clock_t start, end;
	for (int i = 0; i < pop_size; i++)
	{
		//��Ⱥ��ʼ�� 
		initialize(&(ind[i]));
		//������ʼ��Ⱥ 
		ind[i].fitness = evaluate(&(ind[i]));
                ind[i].temp_cost = tc;
	}
        start = clock();
        for (int gen = 0; gen < max_gen; gen++)
        {
		mutation();
		for (int i = 0; i < pop_size; i++)
		{
			SLS(&(ind[i]));
			ind[i].fitness = evaluate(&(ind[i]));
		}
		output << "gen: " <<gen<< endl;
                for (int i = 0; i < pop_size; i++)
		{
		        output << ind[i].fitness << endl;
		}
                sort(ind, ind + pop_size);
		output << "optimu��" << evaluate(&(ind[0])) << endl;
		for (int j = 1; j <= col_num; j++)
		{
			if (ind[0].sol_gene[j].is_in_c == 1)
			{
				output << j << " ";
			}
		}
		output << endl;
		crossover();
	//	FCO();
	}
        end = clock();
        output<<"time cost: "<<(end-start)/CLOCKS_PER_SEC<<endl;
	return 0;
}
/*********���������*******************/
