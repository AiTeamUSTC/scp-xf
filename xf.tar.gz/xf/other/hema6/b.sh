# /bin/sh

for i in {1..5}; do
    ./hema6 scp6$i.txt out6$i.txt 30;
done
#for file in ./sh/*;do
#    echo $file
#    qsub $file
#done
