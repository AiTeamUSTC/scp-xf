# /bin/sh

for i in {1..20}; do
    if [ $i -le 5 ] ; then
      ./hemaNR scpnre$i.txt outnre$i.txt 28;
    elif [ $i -le 10 ] ; then
      ./hemaNR scpnrf$((i-5)).txt outnrf$((i-5)).txt 30;
    elif [ $i -le 15 ] ; then
      ./hemaNR scpnrg$((i-10)).txt outnrg$((i-10)).txt 70;
    elif [ $i -le 20 ] ; then
      ./hemaNR scpnrh$((i-15)).txt outnrh$((i-15)).txt 41;
    fi
done
#for file in ./sh/*;do
#    echo $file
#    qsub $file
#done
