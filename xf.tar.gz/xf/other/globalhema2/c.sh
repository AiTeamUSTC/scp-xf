# /bin/sh

for i in {1..5}; do
    ./ghema scpc$i.txt outc$i.txt 43;
done
#for file in ./sh/*;do
#    echo $file
#    qsub $file
#done
