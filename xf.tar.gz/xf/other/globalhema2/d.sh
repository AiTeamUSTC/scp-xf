# /bin/sh

for i in {1..4}; do
    ./ghema scpd$i.txt outd$i.txt 24;
done
./ghema scpd5.txt outd5.txt  25;
#for file in ./sh/*;do
#    echo $file
#    qsub $file
#done
