# /bin/sh

for i in {1..5}; do
    ./ghema scpe$i.txt oute$i.txt 5;
done
#for file in ./sh/*;do
#    echo $file
#    qsub $file
#done
