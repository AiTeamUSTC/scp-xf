#include<stdio.h>
#include<stdlib.h>
#include<vector>
#include<limits.h>
#include<memory.h>
//#include<sys/times.h>
#include<unistd.h>
#define MAXC 50000
#define MAXR 500000
#include<iostream>
#include<fstream>
using namespace std;
typedef struct column
{
	vector<int> vec_rs;// rows it can cover
}column;
typedef struct row
{
	int weight;
	vector<int> vec_cs; // cols have can cover this row
}row;
int c_num;
int r_num;
column cs[MAXC];
row rs[MAXR];
vector<int> uncov_r;
int sol[40]={13,123,136, 158, 236, 276, 277, 279, 318, 320, 330, 345, 346, 375, 388, 399, 500, 510, 556, 576, 631, 659, 684, 721, 747, 785, 798, 799, 804, 807, 836, 845, 854, 863, 909,928,960,982};
void build_instance2(char *file)
{
	int i,j,k,t;
	ifstream input;
	input.open(file);
	input>>r_num>>c_num;
	for(i=1;i<=c_num;i++)
	{
		input>>k;
	}
	for(i=1;i<=r_num;i++)
	{
		input>>k;
		rs[i].weight=1;
		for(j=0;j<k;j++)
		{
			input>>t;
			rs[i].vec_cs.push_back(t);
			cs[t].vec_rs.push_back(i);
		}
		uncov_r.push_back(i);
	}
}
int main()
{
	char filename[] = "scp41.txt";
        int tempr;
        int j;
	vector<int>::iterator it;   
	build_instance2(filename);
	for(int i = 0; i < 38; i++)
	{
	        j = sol[i];
		for(int t = 0; t < cs[j].vec_rs.size(); t++)
		{
		    tempr = cs[j].vec_rs[t];
		    it = uncov_r.begin();
		    while (it != uncov_r.end())
		    {
			    if ((*it) == tempr)
			    {
				  it = uncov_r.erase(it);
				 break;
			    }                                                                                        
		     	    else
				it++;
		    }   
		}
	}
	if(uncov_r.empty())
	{
	    cout<<"YES"<<endl;
	}
	else 
	{
            cout<<"NO"<<endl;
            for(int i = 0; i < uncov_r.size(); i++)
            {
              cout<<uncov_r[i]<<" ";
            }
            cout<<endl;
        }
return 0; 
	
}
