# /bin/sh

for i in {1..3}; do
    ./ghema scpa$i.txt outa$i.txt 38;
done
./ghema scpa4.txt outa4.txt  37;
./ghema scpa5.txt outa5.txt 38;
#for file in ./sh/*;do
#    echo $file
#    qsub $file
#done
