# /bin/sh

for i in {1..10}; do
    ./hema5 scp5$i.txt out5$i.txt 41;
done
#for file in ./sh/*;do
#    echo $file
#    qsub $file
#done
