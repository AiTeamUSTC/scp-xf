# /bin/sh

for i in {1..25}; do
    if [ $i -le 5 ] ; then
      ./hemaabcde scpa$i.txt outa$i.txt 41;
    elif [ $i -le 10 ] ; then
      ./hemaabcde scpb$((i-5)).txt outb$((i-5)).txt 30;
    elif [ $i -le 15 ] ; then
      ./hemaabcde scpc$((i-10)).txt outc$((i-10)).txt 48;
    elif [ $i -le 20 ] ; then
      ./hemaabcde scpd$((i-15)).txt outd$((i-15)).txt 35;
    elif [ $i -le 25 ] ; then
      ./hemaabcde scpe$((i-20)).txt oute$((i-20)).txt 15;
    fi
done
#for file in ./sh/*;do
#    echo $file
#    qsub $file
#done
