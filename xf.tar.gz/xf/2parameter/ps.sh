# /bin/sh

#for i in {1..8}; do
#    ./ghema scp5$i.txt out5$i.txt 34;
#done
./ps scp44.txt out44.txt 38;
./ps scp51.txt out51.txt 34;
./ps scp52.txt out52.txt  34;
./ps scp510.txt out510.txt 34;
./ps scp64.txt out64.txt 20;
#for file in ./sh/*;do
#    echo $file
#    qsub $file
#done

