# /bin/sh

#for i in {1..8}; do
#    ./ghema scp5$i.txt out5$i.txt 34;
#done
for i in {1..3}; do
    ./ps scpa$i.txt outa$i.txt 38;
done
./ps scpa4.txt outa4.txt 37;
./ps scpa5.txt outa5.txt 38;
./ps scpb1.txt outb1.txt 22;
for i in {1..5}; do
   ./ps scpc$i.txt outc$i.txt 43;
done
for i in {1..4}; do
    ./ps scpd$i.txt outd$i.txt 24;
done
#./ps scpd3.txt outd3.txt 24;
#./ps scpd4.txt outd4.txt 24;
./ps scpd5.txt outd5.txt 25;
./ps scpe1.txt oute1.txt 5;
#for file in ./sh/*;do
#    echo $file
#    qsub $file
#done

